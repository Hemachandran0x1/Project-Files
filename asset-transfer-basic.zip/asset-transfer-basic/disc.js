// Function to calculate percentile for values between 0 and 1
function percentileForZeroToOne(percentile) {
    return percentile / 100;
}

// Calculate percentiles for 4 bins
const binBoundaries = [];
for (let i = 0; i <= 100; i += 25) {
    binBoundaries.push(percentileForZeroToOne(i));
}

// Example continuous values between 0 and 1
const values = [0.1, 0.3, 0.5, 0.7, 0.9, 0.2, 0.4, 0.6, 0.8, 0.25];

// Assign values to bins based on bin boundaries
const discretizedValues = values.map(value => {
    let binIndex = 0;
    while (binIndex < binBoundaries.length && value > binBoundaries[binIndex]) {
        binIndex++;
    }
    return binIndex;
});

// Print bin boundaries and discretized values
console.log("Bin boundaries:", binBoundaries);
console.log("Discretized values:", discretizedValues);
