// Gradient descent optimization algorithm
function minimize(objective, initialGuess, learningRate = 0.01, maxIterations = 1000, tolerance = 1e-5) {
    let params = [...initialGuess];
    let iteration = 0;
    let prevObjectiveValue = Infinity;

    while (iteration < maxIterations) {
        const gradient = params.map((param, index) => {
            const perturbedParams = [...params];
            perturbedParams[index] += tolerance;
            const perturbedObjective = objective(perturbedParams);
            return (perturbedObjective - prevObjectiveValue) / tolerance;
        });

        const newParams = params.map((param, index) => param - learningRate * gradient[index]);

        const newObjectiveValue = objective(newParams);
        if (Math.abs(newObjectiveValue - prevObjectiveValue) < tolerance) {
            break;
        }

        params = newParams;
        prevObjectiveValue = newObjectiveValue;
        iteration++;
    }

    return { x: params, iterations: iteration };
}

function huberLoss(residuals, c) {
    return residuals.map(residual => Math.abs(residual) <= c ? 0.5 * Math.pow(residual, 2) : c * (Math.abs(residual) - 0.5 * c));
}

// M-estimation using Huber loss
function MEstimation(x, y, c = 1.345) {
    // Objective function (Huber loss)
    function objective(beta) {
        const residuals = y.map((yi, i) => yi - x[i].reduce((acc, xi, j) => acc + xi * beta[j], 0));
        return huberLoss(residuals, c).reduce((acc, val) => acc + val, 0);
    }

    // Initial guess for regression coefficients
    const initialGuess = new Array(x[0].length).fill(0);

    // Minimize the objective function using a robust optimization algorithm (e.g., gradient descent)
    const result = minimize(objective, initialGuess);

    // Extract the estimated regression coefficients
    const coefficients = result.x;

    return coefficients;
}

// Example data
const x = [[1, 0.8, 0.6], [1, 0.9, 0.8], [1, 0.7, 0.5], [1, 0.6, 0.4]]; // Intercept, Transaction success rate, Rating factor
const y = [0.75, 0.82, 0.68, 0.72]; // Trust scores

// Fit robust regression model using M-estimation
const coefficients = MEstimation(x, y,1.0);

console.log("Intercept:", coefficients[0]);
console.log("Coefficient for transaction success rate:", coefficients[1]);
console.log("Coefficient for rating factor:", coefficients[2]);

