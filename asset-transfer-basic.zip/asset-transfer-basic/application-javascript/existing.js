'use strict';
const { Gateway, Wallets } = require('fabric-network');
const FabricCAServices = require('fabric-ca-client');
const path = require('path');
const { buildCAClient, registerAndEnrollUser, enrollAdmin } = require('../../test-application/javascript/CAUtil.js');
const { buildCCPOrg1, buildWallet } = require('../../test-application/javascript/AppUtil.js');
const {X509Certificate} = require('crypto') 
const fs = require('fs');
const { exec } = require('child_process');
const channelName = process.env.CHANNEL_NAME || 'mychannel';
const chaincodeName = process.env.CHAINCODE_NAME || 'basic';
//const chaincodeName = 'basicgo';
let trust;
let observations=[];
let rewards=[];
let prevkarmascores;
let prevrewards;
const mspOrg1 = 'Org1MSP';
const walletPath = path.join(__dirname, 'wallet');
const org1UserId = 'javascriptAppUser';
let arr;
let threshold=0.35;
let f=0;
let tc;
let arr1={'0':0,'1':0,'2':0};
let arr2={'0':0,'1':0,'2':0};
let total=0;
let on=0;
let ratings;
let prev;
let rating;
function prettyJSONString(inputString) {
    return JSON.stringify(JSON.parse(inputString), null, 2);
}
function decodeIdBytes(idBytes) {
    return String.fromCharCode.apply(null, idBytes);
}

async function main() {
    try {
        const ccp = buildCCPOrg1();
        const caClient = buildCAClient(FabricCAServices, ccp, 'ca.org1.example.com');
        const wallet = await buildWallet(Wallets, walletPath);
        await enrollAdmin(caClient, wallet, mspOrg1);
        await registerAndEnrollUser(caClient, wallet, mspOrg1, org1UserId, 'org1.department1');
        const gateway = new Gateway();
        let v = 0;let k="Value";let p="Value";let q="Value";
        try {
            await gateway.connect(ccp, {
                wallet,
                identity: org1UserId,
                discovery: { enabled: true, asLocalhost: true }
            });

            const network = await gateway.getNetwork(channelName);
			const contract = network.getContract(chaincodeName);
            const contract1 = network.getContract('rating');
            const contract2 = network.getContract('validation');
            const contract3 = network.getContract('rewards');
            tc=0;
            await contract.submitTransaction('InitLedger');
            await contract3.submitTransaction('InitLedger');
            //let assets = await contract.evaluateTransaction('GetAllAssets')
            //console.log(`*** Result: ${prettyJSONString(assets.toString())}`);            
            console.log('\n--> Submit Transaction: InitLedger, function creates the initial set of assets on the ledger');
            while (true) {
                network.addBlockListener( (err) => {
                    if (err) {
                        if (v != err.blockNumber) {
                            console.error(err);
                            v = err.blockNumber;
                            const startTime = recordStartTime();
                            console.log("Number:" + v);
							console.log(`Block Number: ${err.blockData.header.number.low}`); 
							console.log(`Previous Hash: ${err.blockData.header.previous_hash.toString('hex')}`); 
							console.log(`Data Hash: ${err.blockData.header.data_hash.toString('hex')}`); 
                    		console.log(`Block's transactions:`);
                    		err.blockData.data.data.forEach(transaction => {
                                tc=tc+1;
								console.log("\nNEW Transaction:")
                                const chaincode_nm = transaction.payload.data.actions[0].payload.action.proposal_response_payload.extension.chaincode_id.name
                                console.log("Chaincode Name:"+chaincode_nm);
                                if(chaincode_nm=='basicgo')
                                    total=total+1;
								//console.log("Transaction:"+JSON.stringify(transaction));
                        		console.log(`Transaction ID: ${transaction.payload.header.channel_header.tx_id}`+"\n");
								const endorserIds = transaction.payload.data.actions[0].payload.action.endorsements.map(endorsement =>  {return {
									mspid: endorsement.endorser.mspid,
									id_bytes: decodeIdBytes(endorsement.endorser.id_bytes)
								};
                            
								});
                                if(chaincode_nm=='basicgo')
                                {   
                                    f=1;
                                    endorserIds.map(endorser => {
                                    console.log(endorser.mspid)
                                    let x509 = new X509Certificate(endorser.id_bytes)
                                    //console.log(x509.subject+"\n")
                                    const a = x509.subject[48]+x509.subject[49]+x509.subject[50]+x509.subject[51]+x509.subject[52];
                                    console.log(a);
                                    if(endorser.mspid == "Org1MSP")
                                    {
                                        arr1[x509.subject[52]]=1
                                    }
                                    else if(endorser.mspid == "Org2MSP")
                                    {
                                        arr2[x509.subject[52]]=1
                                    }
                                }); 
                                }
                    			});
                            console.log("Total application trans:"+total);
                            k=getNextLexicalString(k);
                            if(f==1)
                            {
                                f=0;     
                                total=0;                           
                                console.log("prevk:"+k)
                                contract.evaluateTransaction('prevkarmascore').then(prevkarmascores=>{
                                contract2.submitTransaction('CreateValidationTransaction',k,arr1[0],arr1[1],arr1[2],arr2[0],arr2[1],arr2[2]);
                                k=getNextLexicalString(k);
                                contract1.evaluateTransaction('getRatings').then(ratings=>{
                                   console.log(`*** Result: ${prettyJSONString(ratings.toString())}`);
                                rating=JSON.parse(ratings)
                                contract1.submitTransaction('submitratings',p,ratings);
                                p=getNextLexicalString(p);
                                console.log(`*** Result: ${prettyJSONString(prevkarmascores.toString())}`)
                                prev=JSON.parse(prevkarmascores)
                                prev=prevkarma(prev)
                                console.log("PRev:"+JSON.stringify(prev))
                                arr=Calckarma(rating,prev,arr1,arr2);
                                console.log(arr);
                                contract3.evaluateTransaction('prevrewards').then(prevrewards=>{
                                prev=JSON.parse(prevrewards)
                                prev=prevreward(prev);
                                console.log(prev);
                                console.log("ARR"+JSON.stringify(arr))
                                rewards=Calcrewards(arr,prev,threshold);
                                console.log(rewards)
                                contract3.submitTransaction('submitrewards',p,rewards[0],rewards[1],rewards[2],rewards[3],rewards[4],rewards[5]);    
                                contract.submitTransaction('CreateAsset',q,arr[0],arr[1],arr[2],arr[3],arr[4],arr[5]);
                                q=getNextLexicalString(q);  
                                console.log("nextk:"+k)
                                arr1={'0':0,'1':0,'2':0};
                                arr2={'0':0,'1':0,'2':0};
                                });
                                });
                                });
                                console.log('--------------------------------------');
                                //on = 0;
                            }  
                            const endTime = recordEndTime();
                            writeTimeToFile(startTime, endTime,tc);   
                            console.log('--------------------------------------');
                  
                        }
                    }
                });
                await new Promise(resolve => setTimeout(resolve, 1000)); 

            }
        } finally {
            gateway.disconnect();
        }
    } catch (error) {
        console.error(`Error: ${error}`);
        process.exit(1);
    }
}

function recordStartTime() {
    return new Date().toISOString();
}

function recordEndTime() {
    return new Date().toISOString();
}


function writeTimeToFile(start, end, transactionCount) {
    const filePath = 'block_times_exist0.csv';
    const duration = calculateDuration(start, end);
    const data = `${duration}ms,${transactionCount}\n`;

    fs.appendFile(filePath, data, (err) => {
        if (err) {
            console.error('Error writing to file:', err);
        } else {
            console.log('Times recorded successfully.');
        }
    });
}

function calculateDuration(startTime, endTime) {
    const start = new Date(startTime);
    const end = new Date(endTime);
    const durationMs = end - start;
    //const durationSec = durationMs / 1000; // Convert milliseconds to seconds
    return durationMs;
}
function getNextLexicalString(str) {
    let chars = str.split('');
  
    for (let i = chars.length - 1; i >= 0; i--) {
      if (chars[i] !== 'z') {
        chars[i] = String.fromCharCode(chars[i].charCodeAt(0) + 1);
        return chars.join('');
      } else {
        chars[i] = 'a';
      }
    }
  
    return chars.unshift('a');
  }

function Calcrewards(arr,prevrewards,threshold)
{   threshold=0.42;
    //rewards=[...prevrewards]
    rewards={};
    for(let key in prevrewards)
    {    
            rewards[key]=prevrewards[key];
    }

    for(let i in arr)
    {
        rewards[i]=(rewards[i]+arr[i]-threshold);
        console.log("arr:"+arr[i]);
        console.log("threshold"+threshold);
    }
    return rewards;
}
function Calckarma(ratings,prevkarmascore,arr1,arr2)
{
    let k={};
    let a=[arr1[0],arr1[1],arr1[2],arr2[0],arr2[1],arr2[2]]
    ratings.forEach((obj) => {
        Object.keys(obj).forEach((key) => {
            if (obj[key] !== 'from') {
                obj[key] = parseFloat(obj[key]);
            }
        });
    });
        let r={};
        let from;
        let rated=new Set();
        let updatedkarma={};
        let totalkarma = 0;;
        let threshold=0.42
        for(let id in prevkarmascore)
            totalkarma+=prevkarmascore[id]
        console.log("total"+totalkarma);
        for(let key in prevkarmascore)
        {    
            r[key]=0;
            k[key]=0;
            updatedkarma[key]=0;
        }
        for(let i=0;i<ratings.length;i++)
        {   rated=ratings[i];
            console.log("rated array:"+JSON.stringify(rated))
            for (let key in prevkarmascore) {
                from = i;
                //if(a[i]==0)
                //    continue;
                if (from != key) {
                    r[key] += (prevkarmascore[key] * rated[''+key]) / (totalkarma * 10);
                    
                    k[key] += rated[key];
                }
            }
            
        };
        console.log("r"+JSON.stringify(r));
        console.log("k"+JSON.stringify(k));

        for(let i in prevkarmascore)
        {
            if(r[i]>=threshold)
            {
                if(prevkarmascore[i]+(k[i]/(ratings.length*20))<1)
                    updatedkarma[i]=prevkarmascore[i]+(k[i]/(ratings.length*20));
                else
                    updatedkarma[i]=1;
            }
            else
            {
                if(prevkarmascore[i]<r[i])
                    updatedkarma[i]=prevkarmascore[i]/2;
                else
                    updatedkarma[i]=r[i]/2;
            }
        }
        console.log(JSON.stringify(updatedkarma));
        //return updatedkarma;
        return updatedkarma;
}
function prevkarma(prev)
{   console.log(prev[0]);
    //console.log(prev[0][Org1peer0])
    let k={'0':0,'1':0,'2':0,'3':0,'4':0,'5':0}
    k[0]=parseFloat(prev[0].Org1peer0);
    k[1]=parseFloat(prev[0].Org1peer1);
    k[2]=parseFloat(prev[0].Org1peer2);
    k[3]=parseFloat(prev[0].Org1peer0);
    k[4]=parseFloat(prev[0].Org1peer1);
    k[5]=parseFloat(prev[0].Org1peer2);

    return k;
}
function prevreward(prev)
{   console.log(prev[0]);
    //console.log(prev[0][Org1peer0])
    let k={'0':0,'1':0,'2':0,'3':0,'4':0,'5':0}
    k[0]=parseFloat(prev[0].Org1peer0);
    k[1]=parseFloat(prev[0].Org1peer1);
    k[2]=parseFloat(prev[0].Org1peer2);
    k[3]=parseFloat(prev[0].Org1peer0);
    k[4]=parseFloat(prev[0].Org1peer1);
    k[5]=parseFloat(prev[0].Org1peer2);

    return k;
}
main();
