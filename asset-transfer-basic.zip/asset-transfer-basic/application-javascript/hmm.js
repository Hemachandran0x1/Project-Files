'use strict';

let arr1={'0':0};
let arr2={'0':0};
let f=0;
const states = ['HighTrust', 'LowTrust'];
const numBins = 4;
let start_probability = {
    HighTrust: 0.8,
    LowTrust: 0.2
};
let trans_probability = {
    HighTrust: {HighTrust: 0.6, LowTrust: 0.4},
    LowTrust: {LowTrust: 0.4, HighTrust: 0.6}
};
let emit_probability = {
    HighTrust: {"0":0.05,"1":0.05,"2":0.15,"3":0.25,"4":0.05,"5":0.05,"6":0.15,"7":0.25},
    LowTrust: {"0":0.25,"1":0.15,"2":0.05,"3":0.05,"4":0.25,"5":0.15,"6":0.05,"7":0.05}
};
const iterations = 3;
let observations=[1,5,3,7,3,7,3,5,3,0,2,4,2,7,4,5,3,7];
let total=0;


 function main() {

            let tcf=[[0.3,0.73,0.98],[0.3,0.75,0.98],[0.3,0.75,0.98],[0.3,0.75,0.98],[0.3,0.75,0.98],[0.3,0.75,0.98]]
            let rf=[[0.3,0.75,0.98],[0.3,0.75,0.98],[0.3,0.75,0.98],[0.3,0.75,0.98],[0.3,0.75,0.98],[0.3,0.75,0.98]]
            let trust=CalcTrust(tcf,rf);
            console.log(trust);
        } 

function CalcTrust(tcf,rf)
{
    let tcfdisc=0;
    let rfdisc=0;
    let truststate=[];
    for(let i=0;i<6;i++)
    {
        tcfdisc=discretize1(tcf[i],4);
        //console.log(tcfdisc);
        rfdisc=discretize(rf[i],4);
        //console.log(rfdisc);
        //observations=observationsequence(rfdisc, tcfdisc);
        console.log("obs:"+observations)
        let { initialProb, transmissionProb, emissionProb } = convertToArrays(start_probability, trans_probability, emit_probability);
         console.log("initial probabilities:", initialProb);
         console.log(" transmission probabilities:", transmissionProb);
         console.log(" emission probabilities:", emissionProb);
         let { initialProbUpdated, transmissionProbUpdated, emissionProbUpdated } = baumWelch(initialProb, transmissionProb, emissionProb, observations, iterations);
         let { start_probability1, trans_probability1, emit_probability1 } = convertToObjects(initialProbUpdated, transmissionProbUpdated, emissionProbUpdated, states);
          console.log("Updated initial probabilities:", initialProbUpdated);
          console.log("Updated transmission probabilities:", transmissionProbUpdated);
          console.log("Updated emission probabilities:", emissionProbUpdated);
        const result = viterbi(observations, states, start_probability1, trans_probability1, emit_probability1);
        //console.log(result);
        //console.log(result.sequence[result.sequence.length - 1 ]);
        truststate[i]=result.sequence[result.sequence.length - 1 ];
    }
    return truststate;
}
    function observationsequence(arr1, arr2) {
        const result = [];
        const maxLength = Math.max(arr1.length, arr2.length);
    
        for (let i = 0; i < maxLength; i++) {
            if (i < arr1.length) {
                result.push(arr1[i]);
            }
            if (i < arr2.length) {
                result.push(arr2[i]);
            }
        }
        console.log("observation:"+result);
        return result;
    }
    
    function discretize(values, numBins) {
        const binSize = 1 / numBins;
        return values.map(value => Math.floor(value / binSize));
    }
    function discretize1(values, numBins) {
        const binSize = 1 / numBins;
        return values.map(value => Math.floor(value / binSize)+4);
    }
    
    function viterbi(obs, states, start_probability, trans_probability, emit_probability) {
        let V = [{}];
        let path = {};
    
        for (let y of states) {
            V[0][y] = start_probability[y] * emit_probability[y][obs[0]];
            path[y] = [y];
        }
    
        for (let t = 1; t < obs.length; t++) {
            V.push({});
            let newPath = {};
    
            for (let y of states) {
                let [prob, state] = max(states.map(st => {
                    return [V[t - 1][st] * trans_probability[st][y] * emit_probability[y][obs[t]], st];
                }));
                V[t][y] = prob;
                newPath[y] = path[state].concat(y);
            }
    
            path = newPath;
        }
    
        let [prob, state] = max(states.map(y => [V[obs.length - 1][y], y]));
        return {sequence: path[state], probability: prob};
    }
    
    function max(arr) {
        return arr.reduce((a, b) => (a[0] > b[0] ? a : b));
    }
    
    function convertToArrays(start_probability, trans_probability, emit_probability) {
        const states = Object.keys(start_probability);
        const initialProb = states.map(state => start_probability[state]);
        const transmissionProb = states.map(state => states.map(nextState => trans_probability[state][nextState]));
        const emissionProb = states.map(state => Object.values(emit_probability[state]));
        return { initialProb, transmissionProb, emissionProb };
    }
    
    function convertToObjects(initialProb, transmissionProb, emissionProb, states) {
        const start_probability1 = {};
        states.forEach((state, index) => {
            start_probability1[state] = initialProb[index];
        });
        const trans_probability1 = {};
        states.forEach((state, i) => {
            trans_probability1[state] = {};
            states.forEach((nextState, j) => {
                trans_probability1[state][nextState] = transmissionProb[i][j];
            });
        });
        const emit_probability1 = {};
        states.forEach((state, i) => {
            emit_probability1[state] = {};
            emissionProb[i].forEach((value, index) => {
                emit_probability1[state][index.toString()] = value;
            });
        });
        return { start_probability1, trans_probability1, emit_probability1 };
    }
    function baumWelch(initialProb, transmissionProb, emissionProb, observations, iterations) {
        const numStates = initialProb.length;
        const numObservations = observations.length;
        const numIterations = iterations || 100;
    
        for (let iter = 0; iter < numIterations; iter++) {
            const forward = calculateForward(initialProb, transmissionProb, emissionProb, observations);
            const backward = calculateBackward(initialProb, transmissionProb, emissionProb, observations);
            const { eta, xi } = updatePhase(forward, backward, transmissionProb, emissionProb);
            initialProb = updateInitialProb(eta);
            transmissionProb = updateTransitionProb(xi, eta);
            emissionProb = updateEmissionProb(eta, observations, numObservations, numStates);
        }
        return {
            initialProbUpdated: initialProb,
            transmissionProbUpdated: transmissionProb,
            emissionProbUpdated: emissionProb
        };
    }
    
    function calculateForward(initialProb, transitionProb, emissionProb, observations) {
        const numStates = initialProb.length;
        const numObservations = observations.length;
        let forward = [];
        for (let i = 0; i < numStates; i++) {
            forward[i] = [];
        }
        for (let i = 0; i < numStates; i++) {
            forward[i][0] = initialProb[i] * emissionProb[i][observations[0]];
        }
        for (let t = 1; t < numObservations; t++) {
            for (let j = 0; j < numStates; j++) {
                let sum = 0;
                for (let i = 0; i < numStates; i++) {
                    sum += forward[i][t - 1] * transitionProb[i][j];
                }
                forward[j][t] = sum * emissionProb[j][observations[t]];
            }
        }
        for (let t = 0; t < numObservations; t++) {
            let columnSum = forward.reduce((acc, val) => acc + val[t], 0);
            for (let i = 0; i < numStates; i++) {
                forward[i][t] /= columnSum;
            }
        }
        let totalProbability = forward.reduce((acc, val) => acc + val[numObservations - 1], 0);
        return forward;
    }
    
    function calculateBackward(initialProb, transitionProb, emissionProb, observations) {
        const numStates = transitionProb.length;
        const numObservations = observations.length;
        let backward = [];
        for (let i = 0; i < numStates; i++) {
            backward[i] = [];
        }
        for (let i = 0; i < numStates; i++) {
            backward[i][numObservations - 1] = 1;
        }
        for (let t = numObservations - 2; t >= 0; t--) {
            for (let i = 0; i < numStates; i++) {
                let sum = 0;
                for (let j = 0; j < numStates; j++) {
                    sum += transitionProb[i][j] * emissionProb[j][observations[t + 1]] * backward[j][t + 1];
                }
                backward[i][t] = sum;
            }
            let columnSum = backward.reduce((acc, val) => acc + val[t], 0);
            for (let i = 0; i < numStates; i++) {
                backward[i][t] /= columnSum;
            }
        }
        return backward;
    }
    
    function updatePhase(forward, backward, transitionProb, emissionProb) {
        const numStates = forward.length;
        const numObservations = forward[0].length;
        let eta = [];
        let xi = [];
        for (let i = 0; i < numStates; i++) {
            eta[i] = [];
            xi[i] = [];
            for (let j = 0; j < numObservations; j++) {
                eta[i][j] = 0;
                xi[i][j] = [];
                for (let k = 0; k < numStates; k++) {
                    xi[i][j][k] = 0;
                }
            }
        }
        for (let t = 0; t < numObservations; t++) {
            let sumAlphaBeta = 0;
            for (let i = 0; i < numStates; i++) {
                sumAlphaBeta += forward[i][t] * backward[i][t];
            }
            for (let i = 0; i < numStates; i++) {
                eta[i][t] = (forward[i][t] * backward[i][t]) / sumAlphaBeta;
            }
        }
        for (let t = 0; t < numObservations - 1; t++) {
            let sumAlphaBeta = 0;
            for (let i = 0; i < numStates; i++) {
                for (let j = 0; j < numStates; j++) {
                    sumAlphaBeta += forward[i][t] * transitionProb[i][j] * emissionProb[j][observations[t + 1]] * backward[j][t + 1];
                }
            }
            for (let i = 0; i < numStates; i++) {
                for (let j = 0; j < numStates; j++) {
                    xi[i][t][j] = (forward[i][t] * transitionProb[i][j] * emissionProb[j][observations[t + 1]] * backward[j][t + 1]) / sumAlphaBeta;
                }
            }
        }
        return { eta: eta, xi: xi };
    }
    
    function updateInitialProb(eta) {
        const numStates = eta.length;
        let updatedInitialProb = new Array(numStates).fill(0);
        for (let i = 0; i < numStates; i++) {
            updatedInitialProb[i] = eta[i][0];
        }
        return updatedInitialProb;
    }
    
    function updateTransitionProb(xi, eta) {
        const numStates = xi.length;
        let updatedTransitionProb = [];
        for (let i = 0; i < numStates; i++) {
            updatedTransitionProb[i] = new Array(numStates).fill(0);
        }
        for (let i = 0; i < numStates; i++) {
            let sumEta = eta[i].reduce((acc, val) => acc + val, 0);
            for (let j = 0; j < numStates; j++) {
                let sumXi = xi[i].reduce((acc, val) => acc + val[j], 0);
                updatedTransitionProb[i][j] = sumEta !== 0 ? sumXi / sumEta : 0;
            }
        }
        return updatedTransitionProb;
    }
    
    function updateEmissionProb(eta, observations, numObservations, numStates) {
        let updatedEmissionProb = [];
        for (let i = 0; i < numStates; i++) {
            updatedEmissionProb[i] = new Array(numObservations).fill(0);
        }
        for (let i = 0; i < numStates; i++) {
            let sumEta = eta[i].reduce((acc, val) => acc + val, 0);
            for (let j = 0; j < numObservations; j++) {
                let sumEtaY = 0;
                for (let k = 0; k < numObservations; k++) {
                    if (observations[k] === j) {
                        sumEtaY += eta[i][k];
                    }
                }
                updatedEmissionProb[i][j] = sumEta !== 0 ? sumEtaY / sumEta : 0;
            }
        }
        return updatedEmissionProb;
    }
main();
