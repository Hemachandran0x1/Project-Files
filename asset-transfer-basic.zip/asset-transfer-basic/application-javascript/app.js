'use strict';
const { Gateway, Wallets } = require('fabric-network');
const FabricCAServices = require('fabric-ca-client');
const path = require('path');
const { buildCAClient, registerAndEnrollUser, enrollAdmin } = require('../../test-application/javascript/CAUtil.js');
const { buildCCPOrg1, buildWallet } = require('../../test-application/javascript/AppUtil.js');
const {X509Certificate} = require('crypto') 
const fs = require('fs');
const { exec } = require('child_process');

const channelName = process.env.CHANNEL_NAME || 'mychannel';
const chaincodeName = process.env.CHAINCODE_NAME || 'basic';
let trust;
let observations=[];
const mspOrg1 = 'Org1MSP';
const walletPath = path.join(__dirname, 'wallet');
const org1UserId = 'javascriptAppUser';
let arr1={'0':0,'1':0,'2':0};
let arr2={'0':0,'1':0,'2':0};
let f=0;
let t=0;
let dtt;
let peerno;
let remainingnodes=6;
let lowtrustcount=[0,0,0,0,0,0];
let val;
let transactioncount;
let val2;
let total=0;
let on=0;
let tcf2=[[],[],[],[],[],[]];
let rf=[[],[],[],[],[],[]];
const states = ['HighTrust', 'LowTrust'];
const numBins = 4;
let start_probability = {
    HighTrust: 0.8,
    LowTrust: 0.2
};
let trans_probability = {
    HighTrust: {HighTrust: 0.6, LowTrust: 0.4},
    LowTrust: {LowTrust: 0.4, HighTrust: 0.6}
};

let emit_probability = {
    HighTrust: {"0":0.05,"1":0.05,"2":0.15,"3":0.25,"4":0.05,"5":0.05,"6":0.15,"7":0.25} ,
    LowTrust: {"0":0.25,"1":0.15,"2":0.05,"3":0.05,"4":0.25,"5":0.15,"6":0.05,"7":0.05}
};
const iterations = 3;
function prettyJSONString(inputString) {
    return JSON.stringify(JSON.parse(inputString), null, 2);
}
function decodeIdBytes(idBytes) {
    return String.fromCharCode.apply(null, idBytes);
}

async function main() {
    try {
        const ccp = buildCCPOrg1();
        const caClient = buildCAClient(FabricCAServices, ccp, 'ca.org1.example.com');
        const wallet = await buildWallet(Wallets, walletPath);
        await enrollAdmin(caClient, wallet, mspOrg1);
        await registerAndEnrollUser(caClient, wallet, mspOrg1, org1UserId, 'org1.department1');

        const gateway = new Gateway();
        let v = 0;let k="world";let p="world";let q="world";
        try {
            await gateway.connect(ccp, {
                wallet,
                identity: org1UserId,
                discovery: { enabled: true, asLocalhost: true }
            });

            const network = await gateway.getNetwork(channelName);
			const contract = network.getContract(chaincodeName);
            const contract1 = network.getContract('tree');
            const contract2 = network.getContract('trust');
            transactioncount=0;
            while (true) {
                network.addBlockListener( (err) => {
                    if (err) {
                        if (v != err.blockNumber) {
                            console.error(err);
                            v = err.blockNumber;
                            const startTime = recordStartTime();
                            console.log("Number:" + v);
							console.log(`Block Number: ${err.blockData.header.number.low}`); 
							console.log(`Previous Hash: ${err.blockData.header.previous_hash.toString('hex')}`); 
							console.log(`Data Hash: ${err.blockData.header.data_hash.toString('hex')}`); 
                    		// console.log(`Block's transactions:`);
                    		err.blockData.data.data.forEach(transaction => {
                                transactioncount+=1;
								// console.log("\nNEW Transaction:")
                                const chaincode_nm = transaction.payload.data.actions[0].payload.action.proposal_response_payload.extension.chaincode_id.name
                                // console.log("Chaincode Name:"+chaincode_nm);
                                if(chaincode_nm=='basicgo')
                                    total=total+1;
								//console.log("Transaction:"+JSON.stringify(transaction));
                        		// console.log(`Transaction ID: ${transaction.payload.header.channel_header.tx_id}`+"\n");
								const endorserIds = transaction.payload.data.actions[0].payload.action.endorsements.map(endorsement =>  {return {
									mspid: endorsement.endorser.mspid,
									id_bytes: decodeIdBytes(endorsement.endorser.id_bytes)
								};
                            
								});
                                if(chaincode_nm=='basicgo')
                                {   f=1;
                                    endorserIds.map(endorser => {
                                    // console.log(endorser.mspid)
                                    let x509 = new X509Certificate(endorser.id_bytes)
                                    //console.log(x509.subject+"\n")
                                    const a = x509.subject[48]+x509.subject[49]+x509.subject[50]+x509.subject[51]+x509.subject[52];
                                    // console.log(a);
                                    if(endorser.mspid == "Org1MSP")
                                    {
                                        arr1[x509.subject[52]]+=1
                                    }
                                    else if(endorser.mspid == "Org2MSP")
                                    {
                                        arr2[x509.subject[52]]+=1
                                    }
                                    
                                });                                    
                                }
                    			});
                            console.log("Total application trans:"+total);
                            k=getNextLexicalString(k);
                            if(f==1)
                            {
                                f=0;  
                                t+=1;                              
                                // console.log("prevk:"+k)
                                contract.submitTransaction('CreateAsset',k , arr1[0]/total,arr2[0]/total,arr1[1]/total,arr2[1]/total,arr1[2]/total,arr2[2]/total);  
                                k=getNextLexicalString(k);
                                console.log("nextk:"+k)
                                arr1={'0':0,'1':0,'2':0};
                                arr2={'0':0,'1':0,'2':0};
                                total=0;
                                if(t>=10)
                                {   
                                    contract.evaluateTransaction('Transacfactor').then(val => {
                                        val2 = JSON.parse(val);
                                        // console.log("TCF:" + val2);
                                        for (let i = 0; i < 6; i++)
                                            {console.log(val2[i]);tcf2[i].push(val2[i]);}
                                    //console.log("TCF sequence:" + tcf2[0]);
                                    contract1.evaluateTransaction('Dttvalue').then(a => {
                                        dtt = JSON.parse(a);
                                        //console.log(dtt);
                                        for (let i = 0; i < 6; i++)
                                            rf[i].push(dtt[i]);
                                        //console.log("RF sequence:" + rf);
                                        contract1.submitTransaction('CreateAsset', p, dtt[0], dtt[1], dtt[2], dtt[3], dtt[4], dtt[5]);
                                        p = getNextLexicalString(p);
                                        console.log("rf:"+rf);
                                        console.log("TCF:"+tcf2);
                                        if(on>=4)
                                        {   trust=CalcTrust(tcf2,rf);
                                            for(let z=0;z<6;z++)
                                            {
                                                if(trust[z]=='LowTrust')
                                                    lowtrustcount[z]+=1;
                                                if(lowtrustcount[z]==3 && remainingnodes>4)
                                                {
                                                    removelowtrustnodes(remainingnodes,z);
                                                    remainingnodes=remainingnodes-1;
                                                }
                                            }
                                            // console.log(JSON.stringify(lowtrustcount));
                                            contract2.submitTransaction('CreateAsset',q,trust[0],trust[1],trust[2],trust[3],trust[4],trust[5]);
                                            q= getNextLexicalString(q);
                                            tcf2=[[],[],[],[],[],[]];
                                            rf=[[],[],[],[],[],[]];
                                            on=0
                                        }
                                        //t=0;
                                        on++;
                                    });
                                    });
                                }
                                    console.log('--------------------------------------');                                
                            }
                            const endTime = recordEndTime();
                            writeTimeToFile(startTime, endTime,transactioncount);    
                            console.log('--------------------------------------');
                  
                        }
                    }
                });                
                await new Promise(resolve => setTimeout(resolve, 1000)); 

            }
        } finally {
            gateway.disconnect();
        }
    } catch (error) {
        console.error(`Error: ${error}`);
        process.exit(1);
    }
}
function getNextLexicalString(str) {
    let chars = str.split('');
  
    for (let i = chars.length - 1; i >= 0; i--) {
      if (chars[i] !== 'z') {
        chars[i] = String.fromCharCode(chars[i].charCodeAt(0) + 1);
        return chars.join('');
      } else {
        chars[i] = 'a';
      }
    }
  
    return chars.unshift('a');
  }


    function recordStartTime() {
        return new Date().toISOString();
    }

    function recordEndTime() {
        return new Date().toISOString();
    }


    function writeTimeToFile(start, end, transactionCount) {
        const filePath = 'block_times_prop_dyn1.csv';
        const duration = calculateDuration(start, end);
        const data = `${duration}ms,${transactionCount}\n`;

        fs.appendFile(filePath, data, (err) => {
            if (err) {
                console.error('Error writing to file:', err);
            } else {
                console.log('Times recorded successfully.');
            }
        });
    }

    function calculateDuration(startTime, endTime) {
        const start = new Date(startTime);
        const end = new Date(endTime);
        const durationMs = end - start;
        return durationMs;
    }
    

    function generateInitialCommands(peerno) {
        switch(peerno) {
            case 0:
                return [
                    "cd ~/go/src/github.com/Hemachandran0x1/fabric-samples/test-network && " +
                    "pwd && " +
                    "export PATH=${PWD}/../bin:$PATH && " +
                    "export FABRIC_CFG_PATH=$PWD/../config/ && " +
                    "export CORE_PEER_TLS_ENABLED=true && " +
                    "export CORE_PEER_LOCALMSPID=\"Org1MSP\" && " +
                    "export CORE_PEER_TLS_ROOTCERT_FILE=${PWD}/organizations/peerOrganizations/org1.example.com/peers/peer0.org1.example.com/tls/ca.crt && " +
                    "export CORE_PEER_MSPCONFIGPATH=${PWD}/organizations/peerOrganizations/org1.example.com/users/Admin@org1.example.com/msp && " +
                    "export CORE_PEER_ADDRESS=localhost:7051 && " +
                    "peer node unjoin -c mychannel"
                ];
            case 1:
                return [
                    "cd ~/go/src/github.com/Hemachandran0x1/fabric-samples/test-network && " +
                    "pwd && " +
                    "export PATH=${PWD}/../bin:$PATH && " +
                    "export FABRIC_CFG_PATH=$PWD/../config/ && " +
                    "export CORE_PEER_TLS_ENABLED=true && " +
                    "export CORE_PEER_LOCALMSPID=\"Org1MSP\" && " +
                    "export CORE_PEER_TLS_ROOTCERT_FILE=${PWD}/organizations/peerOrganizations/org1.example.com/peers/peer1.org1.example.com/tls/ca.crt && " +
                    "export CORE_PEER_MSPCONFIGPATH=${PWD}/organizations/peerOrganizations/org1.example.com/users/Admin@org1.example.com/msp && " +
                    "export CORE_PEER_ADDRESS=localhost:7061 && "+
                    "peer node unjoin -c mychannel"
    
                ];
            case 2:
                return [
                    "cd ~/go/src/github.com/Hemachandran0x1/fabric-samples/test-network && " +
                    "pwd && " +
                    "export PATH=${PWD}/../bin:$PATH && " +
                    "export FABRIC_CFG_PATH=$PWD/../config/ && " +
                    "export CORE_PEER_TLS_ENABLED=true && " +
                    "export CORE_PEER_LOCALMSPID=\"Org1MSP\" && " +
                    "export CORE_PEER_TLS_ROOTCERT_FILE=${PWD}/organizations/peerOrganizations/org1.example.com/peers/peer2.org1.example.com/tls/ca.crt && " +
                    "export CORE_PEER_MSPCONFIGPATH=${PWD}/organizations/peerOrganizations/org1.example.com/users/Admin@org1.example.com/msp && " +
                    "export CORE_PEER_ADDRESS=localhost:7071 && " +
                    "peer node unjoin -c mychannel"
                ];
            case 3:
                return [
                    "cd ~/go/src/github.com/Hemachandran0x1/fabric-samples/test-network && " +
                    "pwd && " +
                    "export PATH=${PWD}/../bin:$PATH && " +
                    "export FABRIC_CFG_PATH=$PWD/../config/ && " +
                    "export CORE_PEER_TLS_ENABLED=true && " +
                    "export CORE_PEER_LOCALMSPID=\"Org2MSP\" && " +
                    "export CORE_PEER_TLS_ROOTCERT_FILE=${PWD}/organizations/peerOrganizations/org2.example.com/peers/peer0.org2.example.com/tls/ca.crt && " +
                    "export CORE_PEER_MSPCONFIGPATH=${PWD}/organizations/peerOrganizations/org2.example.com/users/Admin@org2.example.com/msp && " +
                    "export CORE_PEER_ADDRESS=localhost:9051 && " +
                    "peer node unjoin -c mychannel"
                ];
            case 4:
                return [
                    "cd ~/go/src/github.com/Hemachandran0x1/fabric-samples/test-network && " +
                    "pwd && " +
                    "export PATH=${PWD}/../bin:$PATH && " +
                    "export FABRIC_CFG_PATH=$PWD/../config/ && " +
                    "export CORE_PEER_TLS_ENABLED=true && " +
                    "export CORE_PEER_LOCALMSPID=\"Org2MSP\" && " +
                    "export CORE_PEER_TLS_ROOTCERT_FILE=${PWD}/organizations/peerOrganizations/org2.example.com/peers/peer1.org2.example.com/tls/ca.crt && " +
                    "export CORE_PEER_MSPCONFIGPATH=${PWD}/organizations/peerOrganizations/org2.example.com/users/Admin@org2.example.com/msp && " +
                    "export CORE_PEER_ADDRESS=localhost:9061 && " +
                    "peer node unjoin -c mychannel"
                ];
            case 5:
                return [
                    "cd ~/go/src/github.com/Hemachandran0x1/fabric-samples/test-network && " +
                    "pwd && " +
                    "export PATH=${PWD}/../bin:$PATH && " +
                    "export FABRIC_CFG_PATH=$PWD/../config/ && " +
                    "export CORE_PEER_TLS_ENABLED=true && " +
                    "export CORE_PEER_LOCALMSPID=\"Org2MSP\" && " +
                    "export CORE_PEER_TLS_ROOTCERT_FILE=${PWD}/organizations/peerOrganizations/org2.example.com/peers/peer2.org2.example.com/tls/ca.crt && " +
                    "export CORE_PEER_MSPCONFIGPATH=${PWD}/organizations/peerOrganizations/org2.example.com/users/Admin@org2.example.com/msp && " +
                    "export CORE_PEER_ADDRESS=localhost:9071 && " +
                    "peer node unjoin -c mychannel"
                ];
            default:
                return [];
        }
    }
    
    function removelowtrustnodes(rem,peerno) {
        if (rem > 4) {
            const initialCommands = generateInitialCommands(peerno);
    
            const commands = [...initialCommands];
            console.log("Removing Peer "+peerno+ " due to low trust\n\n");
            commands.forEach(command => {
                exec(command, (error, stdout, stderr) => {
                    if (error) {
                        console.error(`Error executing command: ${command},${stderr}`);
                        return;
                    }
                    console.log(`Command executed successfully: ${command},${stdout}`);
                });
            });
        } else {
            console.log("rem is not greater than 4, skipping commands execution.");
        }
    }  

    
  function CalcTrust(tcf,rf)
  {
      let tcfdisc=0;
      let rfdisc=0;
      let truststate=[];
      for(let i=0;i<6;i++)
      {
        tcfdisc=discretize1(tcf[i],4);
          //console.log(tcfdisc);
        rfdisc=discretize(rf[i],4);
          //console.log(rfdisc);
        observations=observationsequence(rfdisc, tcfdisc);
        console.log("obs:"+observations)
        // let { initialProb, transmissionProb, emissionProb } = convertToArrays(start_probability, trans_probability, emit_probability);
        // let { initialProbUpdated, transmissionProbUpdated, emissionProbUpdated } = baumWelch(initialProb, transmissionProb, emissionProb, observations, iterations);
        // let { start_probability1, trans_probability1, emit_probability1 } = convertToObjects(initialProbUpdated, transmissionProbUpdated, emissionProbUpdated, states);
        // // console.log("Updated initial probabilities:", initialProbUpdated);
        // console.log("Updated transmission probabilities:", transmissionProbUpdated);
        // console.log("Updated emission probabilities:", emissionProbUpdated);
       //const result = viterbi(observations, states, start_probability1, trans_probability1, emit_probability1);
        const result = viterbi(observations, states, start_probability, trans_probability, emit_probability);

        truststate[i]=result.sequence[result.sequence.length - 1 ];
      }
      return truststate;
  }
    function observationsequence(arr1, arr2) {
        const result = [];
        const maxLength = Math.max(arr1.length, arr2.length);
    
        for (let i = 0; i < maxLength; i++) {
            if (i < arr1.length) {
                result.push(arr1[i]);
            }
            if (i < arr2.length) {
                result.push(arr2[i]);
            }
        }
    
        return result;
    }
    
    function discretize(values, numBins) {
        const binSize = 1 / numBins;
        return values.map(value => Math.floor(value / binSize));
    }
    function discretize1(values, numBins) {
        const binSize = 1 / numBins;
        return values.map(value => Math.floor(value / binSize)+4);
    }
    
    function viterbi(obs, states, start_probability, trans_probability, emit_probability) {
        let V = [{}];
        let path = {};
    
        for (let y of states) {
            V[0][y] = start_probability[y] * emit_probability[y][obs[0]];
            path[y] = [y];
        }
    
        for (let t = 1; t < obs.length; t++) {
            V.push({});
            let newPath = {};
    
            for (let y of states) {
                let [prob, state] = max(states.map(st => {
                    return [V[t - 1][st] * trans_probability[st][y] * emit_probability[y][obs[t]], st];
                }));
                V[t][y] = prob;
                newPath[y] = path[state].concat(y);
            }
    
            path = newPath;
        }
    
        let [prob, state] = max(states.map(y => [V[obs.length - 1][y], y]));
        return {sequence: path[state], probability: prob};
    }
    
    function max(arr) {
        return arr.reduce((a, b) => (a[0] > b[0] ? a : b));
    }
    
    function convertToArrays(start_probability, trans_probability, emit_probability) {
        const states = Object.keys(start_probability);
        const initialProb = states.map(state => start_probability[state]);
        const transmissionProb = states.map(state => states.map(nextState => trans_probability[state][nextState]));
        const emissionProb = states.map(state => Object.values(emit_probability[state]));
        return { initialProb, transmissionProb, emissionProb };
    }
    
    function convertToObjects(initialProb, transmissionProb, emissionProb, states) {
        const start_probability1 = {};
        states.forEach((state, index) => {
            start_probability1[state] = initialProb[index];
        });
        const trans_probability1 = {};
        states.forEach((state, i) => {
            trans_probability1[state] = {};
            states.forEach((nextState, j) => {
                trans_probability1[state][nextState] = transmissionProb[i][j];
            });
        });
        const emit_probability1 = {};
        states.forEach((state, i) => {
            emit_probability1[state] = {};
            emissionProb[i].forEach((value, index) => {
                emit_probability1[state][index.toString()] = value;
            });
        });
        return { start_probability1, trans_probability1, emit_probability1 };
    }    
    function baumWelch(initialProb, transmissionProb, emissionProb, observations, iterations) {
        const numStates = initialProb.length;
        const numObservations = observations.length;
        const numIterations = iterations || 100;
    
        for (let iter = 0; iter < numIterations; iter++) {
            const forward = calculateForward(initialProb, transmissionProb, emissionProb, observations);
            const backward = calculateBackward(initialProb, transmissionProb, emissionProb, observations);
            const { eta, xi } = updatePhase(forward, backward, transmissionProb, emissionProb);
            initialProb = updateInitialProb(eta);
            transmissionProb = updateTransitionProb(xi, eta);
            emissionProb = updateEmissionProb(eta, observations, numObservations, numStates);
        }
        return {
            initialProbUpdated: initialProb,
            transmissionProbUpdated: transmissionProb,
            emissionProbUpdated: emissionProb
        };
    }
    
    function calculateForward(initialProb, transitionProb, emissionProb, observations) {
        const numStates = initialProb.length;
        const numObservations = observations.length;
        let forward = [];
        for (let i = 0; i < numStates; i++) {
            forward[i] = [];
        }
        for (let i = 0; i < numStates; i++) {
            forward[i][0] = initialProb[i] * emissionProb[i][observations[0]];
        }
        for (let t = 1; t < numObservations; t++) {
            for (let j = 0; j < numStates; j++) {
                let sum = 0;
                for (let i = 0; i < numStates; i++) {
                    sum += forward[i][t - 1] * transitionProb[i][j];
                }
                forward[j][t] = sum * emissionProb[j][observations[t]];
            }
        }
        for (let t = 0; t < numObservations; t++) {
            let columnSum = forward.reduce((acc, val) => acc + val[t], 0);
            for (let i = 0; i < numStates; i++) {
                forward[i][t] /= columnSum;
            }
        }
        let totalProbability = forward.reduce((acc, val) => acc + val[numObservations - 1], 0);
        return forward;
    }
    
    function calculateBackward(initialProb, transitionProb, emissionProb, observations) {
        const numStates = transitionProb.length;
        const numObservations = observations.length;
        let backward = [];
        for (let i = 0; i < numStates; i++) {
            backward[i] = [];
        }
        for (let i = 0; i < numStates; i++) {
            backward[i][numObservations - 1] = 1;
        }
        for (let t = numObservations - 2; t >= 0; t--) {
            for (let i = 0; i < numStates; i++) {
                let sum = 0;
                for (let j = 0; j < numStates; j++) {
                    sum += transitionProb[i][j] * emissionProb[j][observations[t + 1]] * backward[j][t + 1];
                }
                backward[i][t] = sum;
            }
            let columnSum = backward.reduce((acc, val) => acc + val[t], 0);
            for (let i = 0; i < numStates; i++) {
                backward[i][t] /= columnSum;
            }
        }
        return backward;
    }
    
    function updatePhase(forward, backward, transitionProb, emissionProb) {
        const numStates = forward.length;
        const numObservations = forward[0].length;
        let eta = [];
        let xi = [];
        for (let i = 0; i < numStates; i++) {
            eta[i] = [];
            xi[i] = [];
            for (let j = 0; j < numObservations; j++) {
                eta[i][j] = 0;
                xi[i][j] = [];
                for (let k = 0; k < numStates; k++) {
                    xi[i][j][k] = 0;
                }
            }
        }
        for (let t = 0; t < numObservations; t++) {
            let sumAlphaBeta = 0;
            for (let i = 0; i < numStates; i++) {
                sumAlphaBeta += forward[i][t] * backward[i][t];
            }
            for (let i = 0; i < numStates; i++) {
                eta[i][t] = (forward[i][t] * backward[i][t]) / sumAlphaBeta;
            }
        }
        for (let t = 0; t < numObservations - 1; t++) {
            let sumAlphaBeta = 0;
            for (let i = 0; i < numStates; i++) {
                for (let j = 0; j < numStates; j++) {
                    sumAlphaBeta += forward[i][t] * transitionProb[i][j] * emissionProb[j][observations[t + 1]] * backward[j][t + 1];
                }
            }
            for (let i = 0; i < numStates; i++) {
                for (let j = 0; j < numStates; j++) {
                    xi[i][t][j] = (forward[i][t] * transitionProb[i][j] * emissionProb[j][observations[t + 1]] * backward[j][t + 1]) / sumAlphaBeta;
                }
            }
        }
        return { eta: eta, xi: xi };
    }
    
    function updateInitialProb(eta) {
        const numStates = eta.length;
        let updatedInitialProb = new Array(numStates).fill(0);
        for (let i = 0; i < numStates; i++) {
            updatedInitialProb[i] = eta[i][0];
        }
        return updatedInitialProb;
    }
    
    function updateTransitionProb(xi, eta) {
        const numStates = xi.length;
        let updatedTransitionProb = [];
        for (let i = 0; i < numStates; i++) {
            updatedTransitionProb[i] = new Array(numStates).fill(0);
        }
        for (let i = 0; i < numStates; i++) {
            let sumEta = eta[i].reduce((acc, val) => acc + val, 0);
            for (let j = 0; j < numStates; j++) {
                let sumXi = xi[i].reduce((acc, val) => acc + val[j], 0);
                updatedTransitionProb[i][j] = sumEta !== 0 ? sumXi / sumEta : 0;
            }
        }
        return updatedTransitionProb;
    }
    
    function updateEmissionProb(eta, observations, numObservations, numStates) {
        let updatedEmissionProb = [];
        for (let i = 0; i < numStates; i++) {
            updatedEmissionProb[i] = new Array(numObservations).fill(0);
        }
        for (let i = 0; i < numStates; i++) {
            let sumEta = eta[i].reduce((acc, val) => acc + val, 0);
            for (let j = 0; j < numObservations; j++) {
                let sumEtaY = 0;
                for (let k = 0; k < numObservations; k++) {
                    if (observations[k] === j) {
                        sumEtaY += eta[i][k];
                    }
                }
                updatedEmissionProb[i][j] = sumEta !== 0 ? sumEtaY / sumEta : 0;
            }
        }
        return updatedEmissionProb;
    }
main();
