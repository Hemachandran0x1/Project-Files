'use strict';
const { Gateway, Wallets } = require('fabric-network');
const FabricCAServices = require('fabric-ca-client');
const path = require('path');
const { buildCAClient, registerAndEnrollUser, enrollAdmin } = require('../../test-application/javascript/CAUtil.js');
const { buildCCPOrg1, buildWallet } = require('../../test-application/javascript/AppUtil.js');
const {X509Certificate} = require('crypto'); 
const { channel } = require('diagnostics_channel');
import('tree-model');

const channelName = process.env.CHANNEL_NAME || 'mychannel';
const chaincodeName = process.env.CHAINCODE_NAME || 'basic';

const mspOrg1 = 'Org1MSP';
const walletPath = path.join(__dirname, 'wallet');
const org1UserId = 'javascriptAppUser';

function prettyJSONString(inputString) {
    return JSON.stringify(JSON.parse(inputString), null, 2);
}
function decodeIdBytes(idBytes) {
    return String.fromCharCode.apply(null, idBytes);
}
async function main() {
    try {
        const ccp = buildCCPOrg1();
        const caClient = buildCAClient(FabricCAServices, ccp, 'ca.org1.example.com');
        const wallet = await buildWallet(Wallets, walletPath);
        await enrollAdmin(caClient, wallet, mspOrg1);
        await registerAndEnrollUser(caClient, wallet, mspOrg1, org1UserId, 'org1.department1');

        const gateway = new Gateway();
        let v = 0;let k=1110;let c =0;
        try {
            await gateway.connect(ccp, {
                wallet,
                identity: org1UserId,
                discovery: { enabled: true, asLocalhost: true }
            });

            const network = await gateway.getNetwork(channelName);
            const contract = network.getContract(chaincodeName);
            let startasset = 1111;
            
            //await contract.submitTransaction('InitLedger','1','asset');
          


 network.addBlockListener(async (err, block) => {
    console.log(err.blockNumber);
    console.log(err.blockData.data.data[0].payload.data.actions[0].payload.chaincode_proposal_payload.input.chaincode_spec.input.args[1].toString('utf-8'));

        if(err.blockNumber > 5)
    if (err && err.blockData.data.data[0].payload.data.actions[0].payload.chaincode_proposal_payload.input.chaincode_spec.input.args[2].toString('utf-8') != "history") {
        //k = k+1;

        // Loop through each transaction in the block
        for (const transaction of err.blockData.data.data) {
            // Extract endorsement information from the transaction
            let eorg1peer0 = 0;
            let eorg2peer0 = 0;
            let eorg1peer1 = 0;
            let eorg2peer1 = 0;
            let eorg1peer2 = 0;
            let eorg2peer2 = 0;


            // Process endorsement information
            transaction.payload.data.actions[0].payload.action.endorsements.forEach(endorsement => {
                let x509 = new X509Certificate(decodeIdBytes(endorsement.endorser.id_bytes));
                const peerid = x509.subject[48] + x509.subject[49] + x509.subject[50] + x509.subject[51] + x509.subject[52];
                let orgFindTerm = endorsement.endorser.mspid + "_" + peerid;
                if (orgFindTerm === "Org1MSP_peer0") {
                    eorg1peer0 = 1;
                } else if (orgFindTerm === "Org2MSP_peer0") {
                    eorg2peer0 = 1;
                } else if (orgFindTerm === "Org1MSP_peer1") {
                    eorg1peer1 = 1;
                } else if (orgFindTerm === "Org2MSP_peer1") {
                    eorg2peer1 = 1;
                }else if (orgFindTerm === "Org1MSP_peer2") {
                    eorg1peer2 = 1;
                } else if (orgFindTerm === "Org2MSP_peer2") {
                    eorg2peer2 = 1;
                }
            });
            console.log("invoked")
            
            console.log(err.blockData.data.data[0].payload.data.actions[0].payload.chaincode_proposal_payload.input.chaincode_spec.input.args[1].toString('utf-8'));
                let date1 =  err.blockData.data.data[0].payload.header.channel_header.timestamp;
                let numericValue = Date.parse(date1);

                await contract.submitTransaction('CreateAsset','H' + err.blockData.data.data[0].payload.data.actions[0].payload.chaincode_proposal_payload.input.chaincode_spec.input.args[1].toString('utf-8'),'history',numericValue,eorg1peer0,eorg2peer0,eorg1peer1,eorg2peer1,eorg1peer2,eorg2peer2);
                console.log("Update done submitted successfully");
            // Construct transaction data based on endorsement information
            // const transactionData = {
            //     eorg1peer0: eorg1peer0,
            //     eorg2peer0: eorg2peer0
            // };

            // Submit transaction to the blockchain network
            // try {
            //     console.log(err.blockData.data.data[0].payload.data.actions[0].payload.chaincode_proposal_payload.input.chaincode_spec.input.args[1].toString('utf-8'));
            //     let date1 =  err.blockData.data.data[0].payload.header.channel_header.timestamp;
            //     let numericValue = Date.parse(date1);

            //     await contract.submitTransaction('CreateAsset','H' + err.blockData.data.data[0].payload.data.actions[0].payload.chaincode_proposal_payload.input.chaincode_spec.input.args[1].toString('utf-8'),'history',numericValue,eorg1peer0,eorg2peer0);
            //     console.log("Update done submitted successfully");
            // } catch (error) {
            //     console.error("Error submitting transaction:", error);
            // }
        }
    }
});
// await new Promise(resolve => setTimeout(resolve, 1000)); 
// 
const transactions = [
    ['CreateAsset', '1111', 'asset', 1, 0,0,0,0,0,0],
    ['CreateAsset', '1112', 'asset', 1, 0,0,0,0,0,0],
    ['CreateAsset', '1113', 'asset', 1, 0,0,0,0,0,0],
    ['CreateAsset', '1114', 'asset', 1, 0,0,0,0,0,0],
    ['CreateAsset', '1115', 'asset', 1, 0,0,0,0,0,0],
    ['CreateAsset', '1116', 'asset', 1, 0,0,0,0,0,0],
    ['CreateAsset', '1117', 'asset', 1, 0,0,0,0,0,0],
    ['CreateAsset', '1118', 'asset', 1, 0,0,0,0,0,0],
    ['CreateAsset', '1119', 'asset', 1, 0,0,0,0,0,0],
    ['CreateAsset', '1120', 'asset', 1, 0,0,0,0,0,0]
];

// Submit transactions with delay of 1000 milliseconds (1 second) between each
// for (const transaction of transactions) {
//     let transactionObj = contract.createTransaction(transaction[0]);
//     await transactionObj.submit(...transaction.slice(1));
//     await new Promise(resolve => setTimeout(resolve, 2000)); // Add a delay
// }
for (const transaction of transactions) {
    await contract.submitTransaction(...transaction);
    await new Promise(resolve => setTimeout(resolve, 2000)); // Add a delay
}
const a = await contract.evaluateTransaction('Dttvalue');
await contract.submitTransaction('CreateDttAsset','dtt','history',a);

console.log("dtt" + a);
const nodeDetails = await contract.evaluateTransaction('getneighbournodesforroot');
console.log(nodeDetails.toString('utf-8'));
// let a = nodeDetails.toString('utf-8');
// const ftdtree = await contract.evaluateTransaction('formFTDtree','orderer',a[0]);
// console.log(ftdtree);

} finally {
    gateway.disconnect();
}
} catch (error) {
console.error(`Error: ${error}`);
process.exit(1);
}
}


main();
