//validation and rating transaction pool
// Import transaction class used for verification

const Transaction = require("./transaction");
const Validation = require("./valtransaction");
const Rating = require("./rattransaction");
// Transaction threshold is the limit or the holding capacity of the nodes
// Once this exceeds a new block is generated
const { TRANSACTION_THRESHOLD } = require("./config");

class vrtpool {
  constructor() {
    this.valtransactions = [];
    this.rattransactions = [];
  }

  // pushes transactions in the list
  // returns true if it is full
  // else returns false
  //wallet will contain the node id(secret/hash)
  //thus each node will store the node id and its validation bit
  addValidationTransaction(valtrans) {
   // const valtrans = Validation.createValTransactions(validationBit,wallet);
    this.valtransactions.push(valtrans)
    //this.valtransactions.sort();//ascending default
    /*if (this.valtransactions.length >= TRANSACTION_THRESHOLD) {
      return true;
    } else {
      return false;
    }*/
  }
  exisitingvaltransaction(valtrans) {
    let exists = this.valtransactions.find(b => b.hash === valtrans.hash);
    return exists;
  }
  exisitingrattransaction(rattrans) {
    let exists = this.rattransactions.find(b => b.hash === rattrans.hash);
    return exists;
  }
  getValidationTransaction()
  {
    return this.valtransactions;
  }
  getRatingTransaction()
  {
    return this.rattransactions;
  }
  countValidOnes() {
    let count = 0;
    for (let i = 0; i < this.valtransactions.length; i++) {
      if ( this.valtransactions[i]["validationBit"] == 1) {
        count++;
      }
    }
    console.log("Count:"+count);
    return count;
  }
  //modify
  addRatingTransaction(transaction)
  {
    
    this.rattransactions.push(transaction);
    
  }
  // wrapper function to verify transactions
 // verifyTransaction(transaction) {
  //  return Transaction.verifyTransaction(transaction);
  //}
  nodenotselfrated(){
   //tbd
  }

  
  // empties the pool
  clear() {
    console.log("VRT POOL CLEARED");
    this.valtransactions = [];
    this.rattransactions = [];
  }
}

module.exports = vrtpool;
