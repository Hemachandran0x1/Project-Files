//structure constructor valtrans
// Import the ChainUtil class used for hashing, verification, and signing
const ChainUtil = require("./chain-util");

class ValTransaction {
  constructor(validationBit, id, from, hash, signature) {
    // this.id = ChainUtil.id();
    // this.validationBit = validationBit;
    // this.from = wallet.publicKey;
    // this.hash = ChainUtil.hash({ validationBit, pubkey:wallet.publicKey , timestamp: Date.now() });
    // this.signature = wallet.sign(this.hash);
    this.id = id;
    this.validationBit = validationBit;
    this.hash = hash;
    this.from = from;
    this.signature = signature;
  }

  // Method to verify whether the validation transaction is valid
 /* static verifyValTransaction(valTransaction) {
    const { from, signature, hash, nodePublicKey, nodeDigitalSignature } = valTransaction;
    const isValidSignature = ChainUtil.verifySignature(from, signature, hash);
    const isValidNodeDigitalSignature = ChainUtil.verifySignature(nodePublicKey, nodeDigitalSignature, hash);
    return isValidSignature && isValidNodeDigitalSignature;
  }*/
  static createValTransactions(validationBit,wallet){
    let id = ChainUtil.id();
    let from = wallet.publicKey;
    let hash = ChainUtil.hash({ validationBit, pubkey:wallet.publicKey , timestamp: Date.now() });
    let signature = wallet.sign(this.hash);
    return new this(validationBit,id,from,hash,signature)
  }
}

module.exports = ValTransaction;
