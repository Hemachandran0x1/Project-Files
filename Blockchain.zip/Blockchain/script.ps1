Start-Process powershell.exe -ArgumentList @("-noExit", "-command", "Set-Item -Path Env:\SECRET -Value 'NODE0';Set-Item -Path Env:\NODEID -Value 0;Set-Item -Path Env:\P2P_PORT -Value 5000; Set-Item -Path Env:\HTTP_PORT -Value 3000; node app")
Start-Sleep -Seconds 2
Start-Process powershell.exe -ArgumentList @("-noExit", "-command", "Set-Item -Path Env:\SECRET -Value 'NODE1';Set-Item -Path Env:\NODEID -Value 1; Set-Item -Path Env:\P2P_PORT -Value 5001; Set-Item -Path Env:\HTTP_PORT -Value 3001; Set-Item -Path Env:\PEERS -Value 'ws://localhost:5000'; node app")
Start-Sleep -Seconds 2; 
Start-Process powershell.exe -ArgumentList @("-noExit", "-command", "Set-Item -Path Env:\SECRET -Value 'NODE2';Set-Item -Path Env:\NODEID -Value 2; Set-Item -Path Env:\P2P_PORT -Value 5002; Set-Item -Path Env:\HTTP_PORT -Value 3002; Set-Item -Path Env:\PEERS -Value 'ws://localhost:5001,ws://localhost:5000'; node app")
Start-Sleep -Seconds 2;
#Set-Item -Path Env:\NODEID -Value 1; 