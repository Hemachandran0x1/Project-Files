// import the ws module
const WebSocket = require("ws");
const valtransaction = require("./valtransaction");
const rattransaction = require("./rattransaction");
const Karmascore = require("./karmacalc");
// import the min approval constant which will be used to compare the count the messages
const { MIN_APPROVALS, NUMBER_OF_NODES } = require("./config");
let valtrans;
let bit;
let rattrans;
let rating={};

let block;
// decalre a p2p server port on which it would listen for messages
// we will pass the port through command line
const P2P_PORT = process.env.P2P_PORT || 5001;

// the neighbouring nodes socket addresses will be passed in command line
// this statemet splits them into an array
const peers = process.env.PEERS ? process.env.PEERS.split(",") : [];

// message types used to avoid typing messages
// also used in swtich statement in message handlers
const MESSAGE_TYPE = {
  transaction: "TRANSACTION",
  //prepare: "PREPARE",
  //pre_prepare: "PRE-PREPARE",
  partialblock:"PARTIALBLOCK",
  commit: "COMMIT",
  validation:"VALIDATION",
  rating:"RATING",
  round_change: "ROUND_CHANGE"
};

class P2pserver {
  constructor(
    blockchain,
    transactionPool,
    vrtpool,
    wallet,
    messagePool,
    blockPool,
    partialblockpool,
    commitPool,
    validators
  ) {
    this.blockchain = blockchain;
    this.sockets = [];
    this.transactionPool = transactionPool;
    this.vrtpool = vrtpool;
    this.wallet = wallet;
    this.messagePool=messagePool;
    this.blockPool = blockPool;
    this.partialblockpool = partialblockpool;
    this.commitPool = commitPool;
    this.validators = validators;
    this.rating = {};
    this.ratings = [];
    this.prev=0;
  }

  // Creates a server on a given port
  listen() {
    const server = new WebSocket.Server({ port: P2P_PORT });
    server.on("connection", socket => {
      console.log("new connection");
      this.connectSocket(socket);
    });
    this.connectToPeers();
    console.log(`Listening for peer to peer connection on port : ${P2P_PORT}`);
  }

  // connects to a given socket and registers the message handler on it
  connectSocket(socket) {
    this.sockets.push(socket);
    console.log("Socket connected");
    this.messageHandler(socket);
  }

  // connects to the peers passed in command line
  connectToPeers() {
    peers.forEach(peer => {
      const socket = new WebSocket(peer);
      socket.on("open", () => this.connectSocket(socket));
    });
  }

  // broadcasts transactions
  broadcastTransaction(transaction) {
    this.sockets.forEach(socket => {
      this.sendTransaction(socket, transaction);
    });
  }

  // sends transactions to a perticular socket
  sendTransaction(socket, transaction) {
    socket.send(
      JSON.stringify({
        type: MESSAGE_TYPE.transaction,
        transaction: transaction
      })
    );
  }

  broadcastValTransaction(valtransaction) {
    this.sockets.forEach(socket => {
      this.sendValTransaction(socket, valtransaction);
    });
  }

  sendValTransaction(socket, valtransaction) {
    socket.send(
      JSON.stringify({
        type: MESSAGE_TYPE.validation,
        valtransaction: valtransaction
      })
    );
  }

  broadcastratTransaction(rattransaction,validationBit) {
    this.sockets.forEach(socket => {
      this.sendratTransaction(socket, rattransaction,validationBit);
    });
  }

  sendratTransaction(socket, rattransaction,validationBit) {
    socket.send(
      JSON.stringify({
        type: MESSAGE_TYPE.rating,
        rattransaction: rattransaction,
        validationBit: validationBit
      })
    );
  }
  // broadcasts preprepare
  broadcastpartialblock(block) {
    this.sockets.forEach(socket => {
      this.sendpartialblock(socket, block);
    });
  }

  // sends Partialblock to a particular socket
  sendpartialblock(socket, block) {
    socket.send(
      JSON.stringify({
        type: MESSAGE_TYPE.partialblock,
        block: block
      })
    );
  }

 
  // broadcasts commit
  broadcastCommit() {
    this.sockets.forEach(socket => {
      this.sendCommit(socket);
    });
  }

  // sends commit to a particular socket
  sendCommit(socket, commit) {
    socket.send(
      JSON.stringify({
        type: MESSAGE_TYPE.commit,

      })
    );
  }

  // broacasts round change
  broadcastRoundChange(karmascore,valbit) {
    this.sockets.forEach(socket => {
      this.sendRoundChange(socket, karmascore,valbit);
    });
  }

  // sends round change message to a particular socket
  sendRoundChange(socket, karmascore,valbit) {
    socket.send(
      JSON.stringify({
        type: MESSAGE_TYPE.round_change,
        karmascore: karmascore,
        valbit:valbit
      })
    );
  }

  // handles any message sent to the current node
  messageHandler(socket) {
    // registers message handler
    socket.on("message", message => {
      const data = JSON.parse(message);

      console.log("RECEIVED", data.type);

      // select a perticular message handler
      switch (data.type) {
        case MESSAGE_TYPE.transaction:
          // check if transactions is valid
          if (data.transaction &&
            !this.transactionPool.transactionExists(data.transaction) &&
            this.transactionPool.verifyTransaction(data.transaction) &&
            this.validators.isValidValidator(data.transaction.from)
          ) {
            let thresholdReached = this.transactionPool.addTransaction(
              data.transaction
            );
            // send transactions to other nodes
            // check if limit reached
            if (thresholdReached) {
              console.log("THRESHOLD REACHED");
              // check the current node is the proposer
              if (this.blockchain.getProposer() == this.wallet.getPublicKey()) {
                console.log("PROPOSING Partial BLOCK");
                // if the node is the proposer, create a block and broadcast it
                  this.block = this.blockchain.createPartialBlock(
                  this.transactionPool.transactions,
                  this.wallet
                );
                console.log("CREATED Partial BLOCK", this.block);
                this.broadcastpartialblock(this.block);
              }
              //else 
              //  this.broadcastTransaction(data.transaction);

            } 
            else {
              console.log("Transaction Added");
              //this.broadcastTransaction(data.transaction);
            }
          }
          break;
          case MESSAGE_TYPE.partialblock:
          if (!this.partialblockpool.exisitingPartialBlock(data.block) && this.blockchain.isValidPartialBlock(data.block)) 
            {//console.log("works");
            // add block to pool
              this.partialblockpool.addPartialBlock(data.block);
              this.block=data.block;
              //this.broadcastpartialblock(data.block);
              if(this.blockchain.getProposer() != this.wallet.getPublicKey())
              {
                this.valtrans = valtransaction.createValTransactions(1,this.wallet);
                this.vrtpool.addValidationTransaction(this.valtrans); 
                this.broadcastValTransaction(this.valtrans);
                console.log("1 Validated");}
               // console.log(this.valtrans);
            }
          else if(!this.partialblockpool.exisitingPartialBlock(data.block) &&
          !this.blockchain.isValidPartialBlock(data.block))
            {
              this.partialblockpool.addPartialBlock(data.block);
              this.block=data.block;
              //this.broadcastpartialblock(data.block);
              if(this.blockchain.getProposer() != this.wallet.getPublicKey())
              {
                this.valtrans = valtransaction.createValTransactions(0,this.wallet);
                this.vrtpool.addValidationTransaction(this.valtrans); 
                //console.log(this.valtrans);
                this.broadcastValTransaction(this.valtrans);
                console.log(" 0 Validated");
              }
            }
            else
            {
              console.log("Block exists");
            }
          break;
        case MESSAGE_TYPE.validation: 
          //console.log(data.valtransaction)
          //console.log(this.valtrans);
          if(data.valtransaction && !this.vrtpool.exisitingvaltransaction(data.valtransaction))
            {
              this.vrtpool.addValidationTransaction(data.valtransaction);
              //this.broadcastValTransaction(data.valtransaction);
              console.log("validation transaction received");
              if(this.blockchain.getProposer() != this.wallet.getPublicKey())
              {if (this.vrtpool.countValidOnes()>=MIN_APPROVALS && this.vrtpool.valtransactions.length>=NUMBER_OF_NODES-1 )
              { console.log("Listof valtrans:"+JSON.stringify(this.vrtpool.valtransactions));
              for (let i = 0; i < NUMBER_OF_NODES; i++) {
                if (i !== this.wallet.nodeid) {
                  if(i%2==0)
                    {this.rating["" + i] = (Math.floor(Math.random() * 6));}
                    else
                    {
                      this.rating["" + i] = (Math.floor(Math.random() * 6)+5);
                    }
                }
              }
              
                this.rating["from"]=this.wallet.nodeid;
                //console.log(this.rating);
                this.rattrans= new rattransaction(this.rating,this.wallet);
                if(!this.vrtpool.exisitingrattransaction(this.rattrans))
                {
                  this.vrtpool.addRatingTransaction(this.rattrans);}
                  this.ratings.push(this.rating);//patch
                  this.broadcastratTransaction(this.rattrans,this.valtrans.validationBit);
                  this.bit=1;
                }
              else if(this.vrtpool.valtransactions.length>=NUMBER_OF_NODES-1 && this.vrtpool.countValidOnes()<MIN_APPROVALS)
              {
                console.log("Partial Block Invalid")
                for (let i = 0; i < NUMBER_OF_NODES; i++) {
                  if (i !== this.wallet.nodeid) {
                    if(i%2==0)
                    {this.rating["" + i] = (Math.floor(Math.random() * 10)+1);}
                    
                  }
                }                              
                this.rating["from"]=this.wallet.nodeid;
                //console.log(this.rating);
                this.bit=0;
                this.rattrans= new rattransaction(this.rating,this.wallet);
                if(!this.vrtpool.exisitingrattransaction(this.rattrans))
                {this.vrtpool.addRatingTransaction(this.rattrans);
                  this.ratings.push(this.rating);//patch
                  console.log(data.rattransaction);
                  this.broadcastratTransaction(this.rattrans,this.valtrans.validationBit);
                }}
              else 
                this.broadcastValTransaction(this.valtrans);
           }
          
          }
          break;
        case MESSAGE_TYPE.rating:
          if(data.rattransaction && !this.vrtpool.exisitingrattransaction(data.rattransaction))
           {  if(this.bit==data.validationBit)  
                {this.ratings.push(data.rattransaction.ratings);}
              this.vrtpool.addRatingTransaction(data.rattransaction);
              console.log("read:"+JSON.stringify(data.rattransaction.ratings));
              //console.log(data.rattransaction);
              this.prev=this.blockchain.getProposer();
              if(this.vrtpool.rattransactions.length>=NUMBER_OF_NODES-1)
                this.broadcastCommit();
              //else
               // {this.broadcastratTransaction(this.rattrans,this.bit);
                //  console.log(this.rattrans);
                //}
              //this.broadcastratTransaction(data.rattransaction,data.rattransaction.validationBit);
              //console.log("ratings sent"+JSON.stringify(this.ratings));         
            } 

          
            //this.broadcastratTransaction(data.rattransaction,data.validationBit);
            break;

            case MESSAGE_TYPE.commit:
              {
                if(this.vrtpool.rattransactions.length>=NUMBER_OF_NODES-1)
                  { //console.log("ratings sent"+JSON.stringify(this.ratings));
                  //console.log("list of ratrans:"+JSON.stringify(this.vrtpool.rattransactions));
                 
                  this.karmascores=Karmascore.karmascorecalc(this.ratings,this.wallet,this.blockchain,0.4);
                  if(this.prev != this.wallet.getPublicKey())
                  {
                    this.broadcastRoundChange(this.karmascores,this.bit);
                    this.completeblock=this.blockchain.createBlock(this.wallet,this.block,this.bit,this.vrtpool,this.karmascores);
                  //this.blockchain.addBlock(this.completeblock);
                    console.log("Karma Scores updated");
                    console.log(this.karmascores);
                    console.log(this.completeblock);
                    this.transactionPool.clear();
                    this.vrtpool.clear();
                    this.partialblockpool.clear();
                    this.blockchain.addBlock(this.completeblock);
                }
              }
            }
            break;
              
            case MESSAGE_TYPE.round_change:
              {
                if(this.prev == this.wallet.getPublicKey())
                { //console.log("FLL:"+data.karmascore) 
                  this.completeblock=this.blockchain.createBlock(this.wallet,this.block,data.valbit,this.vrtpool,data.karmascore);
                  //this.blockchain.addBlock(this.completeblock);
                    console.log("Karma Scores updated");
                    console.log(this.karmascores);
                    console.log(this.completeblock);
                    this.transactionPool.clear();
                    this.vrtpool.clear();
                    this.blockchain.addBlock(this.completeblock);
                    this.prev=10;
                } 
              }
            break;
      }
    });
  }
}

module.exports = P2pserver;


