#!/bin/bash

# Define the directory path
directory="/home/user0x1/Desktop/sawtooth/Blockchain"

# Define the array of commands
commands=(
    'cd "$directory" && SECRET="NODE0" NODEID=0 P2P_PORT=5000 HTTP_PORT=3000 PEERS=ws://localhost:5000 node app'
    'cd "$directory" && SECRET="NODE1" NODEID=1 P2P_PORT=5001 HTTP_PORT=3001 PEERS=ws://localhost:5001,ws://localhost:5000 node app'
    'cd "$directory" && SECRET="NODE2" NODEID=2 P2P_PORT=5002 HTTP_PORT=3002 PEERS=ws://localhost:5002,ws://localhost:5001,ws://localhost:5000 node app'
    'cd "$directory" && SECRET="NODE3" NODEID=3 P2P_PORT=5003 HTTP_PORT=3003 PEERS=ws://localhost:5003,ws://localhost:5002,ws://localhost:5001,ws://localhost:5000 node app'
    'cd "$directory" && SECRET="NODE4" NODEID=4 P2P_PORT=5004 HTTP_PORT=3004 PEERS=ws://localhost:5004,ws://localhost:5003,ws://localhost:5002,ws://localhost:5001,ws://localhost:5000 node app'
    'cd "$directory" && SECRET="NODE5" NODEID=5 P2P_PORT=5005 HTTP_PORT=3005 PEERS=ws://localhost:5005,ws://localhost:5004,ws://localhost:5003,ws://localhost:5002,ws://localhost:5001,ws://localhost:5000 node app'
    'cd "$directory" && SECRET="NODE6" NODEID=6 P2P_PORT=5006 HTTP_PORT=3006 PEERS=ws://localhost:5006,ws://localhost:5005,ws://localhost:5004,ws://localhost:5003,ws://localhost:5002,ws://localhost:5001,ws://localhost:5000 node app'
    'cd "$directory" && SECRET="NODE7" NODEID=7 P2P_PORT=5007 HTTP_PORT=3007 PEERS=ws://localhost:5007,ws://localhost:5006,ws://localhost:5005,ws://localhost:5004,ws://localhost:5003,ws://localhost:5002,ws://localhost:5001,ws://localhost:5000 node app'
    'cd "$directory" && SECRET="NODE8" NODEID=8 P2P_PORT=5008 HTTP_PORT=3008 PEERS=ws://localhost:5008,ws://localhost:5007,ws://localhost:5006,ws://localhost:5005,ws://localhost:5004,ws://localhost:5003,ws://localhost:5002,ws://localhost:5001,ws://localhost:5000 node app'
    'cd "$directory" && SECRET="NODE9" NODEID=9 P2P_PORT=5009 HTTP_PORT=3009 PEERS=ws://localhost:5009,ws://localhost:5008,ws://localhost:5007,ws://localhost:5006,ws://localhost:5005,ws://localhost:5004,ws://localhost:5003,ws://localhost:5002,ws://localhost:5001,ws://localhost:5000 node app'
)

# Loop through each command and open a terminal for each
for command in "${commands[@]}"; do
    gnome-terminal -- bash -c "$command;  exec bash" &
    sleep 1
done
