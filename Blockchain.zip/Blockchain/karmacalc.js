const blockchain = require("./blockchain")
const { MIN_APPROVALS, NUMBER_OF_NODES } = require("./config");

class Karmascore
{
    constructor()
    {
        this.kscoretemp={};
        this.finalkscore={};
    }
    karmascorecalc(ratings,wallet,blockchain,threshold)
    {
        let k={};
        let r={};
        let from;
        let rated=new Set();
        let updatedkarma={};
        let scores = blockchain.getKarmascores()
        let totalkarma = 0;;
        for(let id in scores)
            totalkarma+=scores[id]
        for(let key in scores)
        {    
            r[key]=0;
            k[key]=0;
            updatedkarma[key]=0;
        }
        for(let i=0;i<ratings.length;i++)
        {   rated=ratings[i];
            for (let key in scores) {
                from = rated["from"];
                
                if (from != key) {
                    r[key] += (scores[key] * rated[key]) / (totalkarma * 10);
                    k[key] += rated[key];
                }
            }
        };
        for(let i in r)
        {
            console.log(i+":"+r[i]);
            console.log("avg"+k[i]+','+(k[i]/(ratings.length))/20)
        }
        for(let i in scores)
        {
            if(r[i]>=threshold)
            {
                if(scores[i]+(k[i]/(ratings.length*20))<1)
                    updatedkarma[i]=scores[i]+(k[i]/(ratings.length*20));
                else
                    updatedkarma[i]=1;
            }
            else
            {
                if(scores[i]<r[i])
                    updatedkarma[i]=scores[i]/2;
                else
                    updatedkarma[i]=r[i]/2;
            }
        }
        wallet.karmascore = updatedkarma[wallet.nodeid];
        return updatedkarma; 
    }
}

module.exports = Karmascore;
module.exports.karmascorecalc = Karmascore.prototype.karmascorecalc;
