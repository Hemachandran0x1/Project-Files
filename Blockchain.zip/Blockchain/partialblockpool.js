const Block = require("./block");

class PartialBlockPool {
  constructor() {
    this.list = [];
  }

  // check if the block exisits or not
  exisitingPartialBlock(block) {
    let exists = this.list.find(b => b.hash === block.hash);
    console.log(exists);
    //console.log(b.hash+"\n"+b.timestamp);
    //console.log(block.timestamp + "\n"+b.timestamp);
    return exists;
  }

  // pushes block to the chain
  addPartialBlock(block) {
    this.list.push(block);
    console.log("added partial block to pool");
  }
  getblocks()
  {
    return this.list;
  }
  // returns the blcok for the given hash
  getBlock(hash) {
    let exists = this.list.find(b => b.hash === hash);
    return exists;
  }
  clear() {
    console.log("Partialblock POOL CLEARED");
    this.list = [];
  }
}

module.exports = PartialBlockPool;
