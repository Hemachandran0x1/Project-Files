// Import total number of nodes used to create validators list
const { NUMBER_OF_NODES } = require("../config");

// Used to verify block
const Block = require("./Block1");
const partialblock = require("../partialblock")
class Blockchain {
  // the constructor takes an argument validators class object
  // this is used to create a list of validators
  constructor(validators) {
    this.validatorList = validators.generateAddresses(NUMBER_OF_NODES);
    this.chain = [Block.genesis()];
  }

  // pushes confirmed blocks into the chain
  addBlock(block,vrtPool,karmascores) {
    block.validationtransactions=vrtPool.getValidationtransaction();
    block.ratingtransaction=vrtPool.getRatingtransaction();
    block.karmascores=karmascores;
    this.chain.push(block);
    console.log("NEW BLOCK ADDED TO CHAIN");
    return block;
  }
  createPartialBlock(transactions,wallet)
  {
    const partblock = partialblock.createPartialBlock(
        transactions,
        wallet
      );
      return partblock; 
  }
  // wrapper function to create blocks
  createBlock( wallet,partialblockpool,blocktype) {

    const block = Block.createBlock(
      this.chain[this.chain.length - 1],
      wallet,
      blocktype,
      partialblock
    );
    return block;
  }

  // calculates the next propsers by calculating a random index of the validators list
  // index is calculated using the hash of the latest block
  getProposer() {
    let index =
      this.chain[this.chain.length - 1].hash[0].charCodeAt(0) % NUMBER_OF_NODES;
    return this.validatorList[index];
  }

  // checks if the received block is valid
  isValidBlock(block) {
    const lastBlock = this.chain[this.chain.length - 1];
    if (
      lastBlock.sequenceNo + 1 == block.sequenceNo &&
      block.lastHash === lastBlock.hash &&
      block.hash === Block.blockHash(block) &&
      Block.verifyBlock(block) &&
      Block.verifyProposer(block, this.getProposer())
    ) {
      console.log("BLOCK VALID");
      return true;
    } else {
      console.log("BLOCK INVLAID");
      return false;
    }
  }
  isValidPartialBlock(partblock) {
    if (
      partblock.hash === partialblock.blockHash(partblock) &&
      partialblock.verifyBlock(partblock) &&
      partblock.verifyProposer(partblock, this.getProposer())
    ) {
     // console.log("Partial BLOCK VALID");
      return true;
    } else {
      //console.log("Partial BLOCK INVLAID");
      return false;
    }
  }

  // updates the block by appending the prepare and commit messages to the block
  /*addUpdatedBlock(hash, blockPool, vrtPool, karmascores) {
    let block = blockPool.getBlock(hash);
    block.prepareMessages = preparePool.list[hash];
    block.commitMessages = commitPool.list[hash];
    this.addBlock(block);
  }*/
  //karma score retrieval
  getKarmaScores()
  {
    return this.chain[this.chain.length].karmascores;
  }
}
module.exports = Blockchain;
