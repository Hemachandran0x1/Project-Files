// Import SHA256 used for hashing and ChainUtil for verifying signature
const SHA256 = require("crypto-js/sha256");
const ChainUtil = require("../chain-util");
const PartialBlock = require("../partialblock");

class Block {
  constructor(
    timestamp,
    lastvalidHash,
    lastHash,
    hash,
    blocktype,
    partialblock,
    karmascores,
    ratingtransactions,
    validationtransactions,
    sequenceNo
  ) {
    this.timestamp = timestamp;
    this.lastvalidHash=lastvalidHash;
    this.lastHash = lastHash;
    this.hash = hash;
    //this.data = data;
    this.blocktype=this.blocktype;
    this.partialblock = partialblock;
    this.sequenceNo = sequenceNo;
  }

  // A function to print the block
  toString() {
    return `Block - 
        Timestamp   : ${this.timestamp}
        Last Hash   : ${this.lastHash}
        Last Valid Block : ${this.lastvalidHash}
        Hash        : ${this.hash}
        blocktype   : ${this.blocktype}
        partialblock: ${this.partialblock}
        Sequence No : ${this.sequenceNo}`;
  }

  // The first block by default will the genesis block
  // this function generates the genesis block with random values
  static genesis() {
    return new this(
      `genesis time`,
      "----",
      "----",
      [],
      1,
      "-----",
      0
    );
  }

  // creates a block using the passed lastblock, transactions and wallet instance
  static createBlock(lastBlock, wallet,blocktype,partialblock) {
    let hash;
    let timestamp = Date.now();
    const lastHash = lastBlock.hash;
    if(lastBlock.blocktype==1)
    {
      const lastvalidHash=lastBlock.hash;
    }
    else
    {
      const lastvalidHash=lastBlock.lastvalidHash;
    }
    hash = Block1.hash(timestamp, lastHash, partialblock);
    let proposer = wallet.getPublicKey();
    let signature = Block.signBlockHash(hash, wallet);
    return new this(
      timestamp,
      lastvalidHash,
      lastHash,
      hash,
      blocktype,
      partialblock,
      1 + lastBlock.sequenceNo
    );
  }

  // hashes the passed values
  static hash(timestamp, lastHash, partialblock) {
    return SHA256(JSON.stringify(`${timestamp}${lastHash}${partialblock}`)).toString();
  }

  // returns the hash of a block
  static blockHash(block) {
    const { timestamp, lastHash, partialblock } = block;
    return Block.hash(timestamp, lastHash, partialblock);
  }

  // signs the passed block using the passed wallet instance
 /* static signBlockHash(hash, wallet) {
    return wallet.sign(hash);
  }*/

  // checks if the block is valid
 /* static verifyBlock(block) {
    return ChainUtil.verifySignature(
      block.proposer,
      block.signature,
      Block.hash(block.timestamp, block.lastHash, block.partialblock)
    );
  }*/

  // verifies the proposer of the block with the passed public key
 /* static verifyProposer(block, proposer) {
    return block.proposer == proposer ? true : false;
  }*/
}

module.exports = Block;
