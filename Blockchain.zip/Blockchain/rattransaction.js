//structure constructor ratttrans
// Import the ChainUtil class used for hashing, verification, and signing
const ChainUtil = require("./chain-util");

class RatingTransaction {
  constructor(ratings, wallet) {
    this.id = ChainUtil.id();
    this.ratings = ratings;
    this.from = wallet.publicKey;
    this.hash = ChainUtil.hash({ ratings, pubkey: wallet.pubkey });
    this.signature = wallet.sign(this.hash);
  }
  
  // Method to verify whether the rating transaction is valid
 /* static verifyTransaction(ratingTransaction) {
    const { from, signature, hash, nodePublicKey, nodeDigitalSignature } = ratingTransaction;
    const isValidSignature = ChainUtil.verifySignature(from, signature, hash);
    const isValidNodeDigitalSignature = ChainUtil.verifySignature(nodePublicKey, nodeDigitalSignature, hash);
    return isValidSignature && isValidNodeDigitalSignature;
  }*/
}

module.exports = RatingTransaction;
