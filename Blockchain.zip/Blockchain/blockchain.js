// Import total number of nodes used to create validators list
const { NUMBER_OF_NODES } = require("./config");

// Used to verify block
const Block = require("./block");
const partialblock = require("./partialblock")
class Blockchain {
  // the constructor takes an argument validators class object
  // this is used to create a list of validators
  constructor(validators) {
    this.validatorList = validators.generateAddresses(NUMBER_OF_NODES);
    this.chain = [Block.genesis()];
    this.freqtable=[];
  }

  // pushes confirmed blocks into the chain
  addBlock(block) {
    
    var sizeInBytes = getObjectSizeInBytes(block);
    var formattedSize = formatBytes(sizeInBytes);
    
    // Push the block to the chain
    this.chain.push(block);
    
    // Log the size of the block object
    console.log("NEW BLOCK ADDED TO CHAIN");
    console.log("Size of the block object:", formattedSize);
    
    return block;
  }
  createPartialBlock(transactions,wallet)
  {
    const partblock = partialblock.createPartialBlock(
        transactions,
        wallet
      );
      return partblock; 
  }
  // wrapper function to create blocks
  createBlock( wallet,partialblock,blocktype,vrtPool,karmascores) {

    const block = Block.createBlock(
      this.chain[this.chain.length - 1],
      wallet,
      blocktype,
      partialblock,
      vrtPool,
      karmascores
    );
    return block;
  }

  // calculates the next propsers by calculating a random index of the validators list
  // index is calculated using the hash of the latest block
  getProposer() {
    //let index = this.chain[this.chain.length - 1].sequenceNo % NUMBER_OF_NODES;
    let index =1;
    console.log("proposer:"+index);
    return this.validatorList[index];
  }
  frequencytable(karmascores)
  { let a;
    let total=0;
    for(let key in karmascores)
      total+=karmascores[key];
    for(let key in karmascores)
    {
      a=(karmascores[key]/total) * NUMBER_OF_NODES * 100;
      for(let i=0;i<a;i++)
      {
        this.freqtable.push(key);
      }
    }
    return this.freqtable;
  }
  // checks if the received block is valid
  isValidBlock(block) {
    const lastBlock = this.chain[this.chain.length - 1];
    if (
      lastBlock.sequenceNo + 1 == block.sequenceNo &&
      block.lastHash === lastBlock.hash &&
      block.hash === Block.blockHash(block) &&
      Block.verifyBlock(block) &&
      Block.verifyProposer(block, this.getProposer())
    ) {
      console.log("BLOCK VALID");
      return true;
    } else {
      console.log("BLOCK INVLAID");
      return false;
    }
  }
  isValidPartialBlock(partblock) {
    if (
      partblock.hash === partialblock.blockHash(partblock) &&
      partialblock.verifyPartialBlock(partblock) &&
      partialblock.verifyProposer(partblock, this.getProposer())
    ) {
      console.log("Partial BLOCK VALID");
      return true;
    } else {
      console.log("Partial BLOCK INVLAID");
      return false;
    }
  }

  // updates the block by appending the prepare and commit messages to the block
  /*addUpdatedBlock(hash, blockPool, vrtPool, karmascores) {
    let block = blockPool.getBlock(hash);
    block.prepareMessages = preparePool.list[hash];
    block.commitMessages = commitPool.list[hash];
    this.addBlock(block);
  }*/
  //karma score retrieval
  getKarmascores()
  {
    return this.chain[this.chain.length - 1].karmascores;
  }
}
function getObjectSizeInBytes(obj) {
  // Convert object to JSON string
  var jsonString = JSON.stringify(obj);
  
  // Calculate the size of the string in bytes
  var bytes = new Blob([jsonString]).size;
  
  return bytes;
}

function formatBytes(bytes, decimals = 2) {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const dm = decimals < 0 ? 0 : decimals;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];

  const i = Math.floor(Math.log(bytes) / Math.log(k));

  return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
}
module.exports = Blockchain;
