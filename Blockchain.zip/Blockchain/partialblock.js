// Import SHA256 used for hashing and ChainUtil for verifying signature
const SHA256 = require("crypto-js/sha256");
const ChainUtil = require("./chain-util");

class PartialBlock {
  constructor(
    timestamp,
    hash,
    data,
    proposer,
    signature,
  ) {
    this.timestamp = timestamp;
    this.hash = hash;
    this.data = data;
    this.proposer = proposer;
    this.signature = signature;
  }

  // A function to print the block
  toString() {
    return `Block - 
        Timestamp   : ${this.timestamp}
        Hash        : ${this.hash}
        Data        : ${this.data}
        proposer    : ${this.proposer}
        Signature   : ${this.signature}`;
  }

  // The first block by default will the genesis block
  // this function generates the genesis block with random values
  static genesis() {
    return new this(
      `genesis time`,
      "genesis-hash",
      [],
      "P4@P@53R",
      "SIGN",   
    );
  }

  // creates a block using the passed lastblock, transactions and wallet instance
  static createPartialBlock( data, wallet) {
    let hash;
    let timestamp = Date.now();
    hash = PartialBlock.hash(data);
    let proposer = wallet.getPublicKey();
    let signature = PartialBlock.signBlockHash(hash, wallet);
    return new this(
      timestamp,
      hash,
      data,
      proposer,
      signature,
    );
  }

  // hashes the passed values
  static hash(timestamp,  data) {
    return SHA256(JSON.stringify(`${timestamp}${data}`)).toString();
  }

  // returns the hash of a block
  static blockHash(block) {
    const {   data } = block;
    return PartialBlock.hash( data);
  }

  // signs the passed block using the passed wallet instance
  static signBlockHash(hash, wallet) {
    return wallet.sign(hash);
  }

  // checks if the block is valid
  static verifyPartialBlock(block) {
    return ChainUtil.verifySignature(
      block.proposer,
      block.signature,
      PartialBlock.hash( block.data)
    );
  }

  // verifies the proposer of the block with the passed public key
  static verifyProposer(block, proposer) {
    return block.proposer == proposer ? true : false;
  }
}

module.exports = PartialBlock;
