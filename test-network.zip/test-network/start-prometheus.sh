rm -f ~/go/src/github.com/hariharan/fabric-samples/asset-transfer-basic/application-javascript/wallet/javascriptAppUser.id 
rm -f ~/go/src/github.com/hariharan/fabric-samples/asset-transfer-basic/application-javascript/wallet/admin.id 
sudo ./network.sh down
sudo docker volume list
sudo docker volume prune
sudo docker volume rm compose_peer1.org1.example.com
sudo docker volume rm compose_peer2.org1.example.com
sudo docker volume rm compose_peer1.org2.example.com
sudo docker volume rm compose_peer2.org2.example.com
sudo ./network.sh up createChannel -ca -s couchdb


