setfacl -R -m u:hariharan:rwx /home/user0x1/go/src/github.com/hariharan/fabric-samples/test-network/organizations/
export PATH=${PWD}/../bin:$PATH
export FABRIC_CFG_PATH=${PWD}/../config/
export CORE_PEER_TLS_ENABLED=true
export CORE_PEER_LOCALMSPID="Org1MSP"
export CORE_PEER_TLS_ROOTCERT_FILE=${PWD}/organizations/peerOrganizations/org1.example.com/peers/peer0.org1.example.com/tls/ca.crt
export CORE_PEER_MSPCONFIGPATH=${PWD}/organizations/peerOrganizations/org1.example.com/users/Admin@org1.example.com/msp
export CORE_PEER_ADDRESS=localhost:7051
export CHANNEL_NAME=mychannel
export OUTPUT_DIRECTORY=blocks
blockchainInfo=$(peer channel getinfo -c ${CHANNEL_NAME})
height=$(echo $blockchainInfo | awk -F'"height":' '{print $2}' | cut -d',' -f1)
for ((blockNumber=0; blockNumber<=height; blockNumber++))
do
    peer channel fetch ${blockNumber} -o localhost:7050 --ordererTLSHostnameOverride orderer.example.com -c ${CHANNEL_NAME} --tls --cafile "${PWD}/organizations/ordererOrganizations/example.com/orderers/orderer.example.com/msp/tlscacerts/tlsca.example.com-cert.pem" ${OUTPUT_DIRECTORY}/block${blockNumber}.block
    echo "Block $blockNumber:"
    configtxlator proto_decode --type=common.Block --input=${OUTPUT_DIRECTORY}/block${blockNumber}.block
    echo ""
done

